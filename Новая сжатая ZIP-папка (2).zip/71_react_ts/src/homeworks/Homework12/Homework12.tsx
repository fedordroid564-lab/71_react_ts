import { Homework12Wrapper } from "./styles";

import EmployeeForm from "components/EmployeeForm/EmployeeForm";

function Homework12() {
  return (
    <Homework12Wrapper>
      <EmployeeForm />
    </Homework12Wrapper>
  );
}

export default Homework12;
