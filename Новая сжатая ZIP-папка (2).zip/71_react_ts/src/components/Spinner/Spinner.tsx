import { SpinnerComponent } from "./styles";

function Spinner (){
 return <SpinnerComponent></SpinnerComponent>
}

export default Spinner;