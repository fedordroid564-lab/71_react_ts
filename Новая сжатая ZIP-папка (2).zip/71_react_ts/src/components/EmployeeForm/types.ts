export interface EmployeeFormValues {
  fullName: string;
  age: string;
  jobTitle: string;
  agreement: boolean;
}
