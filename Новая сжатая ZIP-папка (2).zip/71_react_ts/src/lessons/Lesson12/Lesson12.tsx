import LoginForm from "components/LoginForm/LoginForm";
import { Lesson12Wrapper } from "./styles";

function Lesson12() {
  return (
    <Lesson12Wrapper>
      <LoginForm />
    </Lesson12Wrapper>
  );
}

export default Lesson12;
