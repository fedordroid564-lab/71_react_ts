import { HomePage } from "./styles"

function Home() {
  return <HomePage>Content Home page</HomePage>
}

export default Home