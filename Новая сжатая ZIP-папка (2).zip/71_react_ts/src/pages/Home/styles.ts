import styled from "@emotion/styled";

export const HomePage = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  padding: 20px;
  font-size: 30px;
  background-color: #d7cda7ff;
`;
