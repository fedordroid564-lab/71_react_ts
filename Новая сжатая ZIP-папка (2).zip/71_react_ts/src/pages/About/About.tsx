import { AboutPage } from "./styles"

function About() {
  return <AboutPage>Content about page</AboutPage>
}

export default About