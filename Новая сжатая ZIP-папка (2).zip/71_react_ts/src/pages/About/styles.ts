import styled from "@emotion/styled";

export const AboutPage = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  padding: 20px;
  font-size: 30px;
  background-color: #cea7d7ff;
`;
