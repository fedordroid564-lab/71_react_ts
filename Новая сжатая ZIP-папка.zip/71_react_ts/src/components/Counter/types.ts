export interface CounterProps {
  counter: number;
  onPlusClick: () => void;
  onMinusClick: () => void;
}
